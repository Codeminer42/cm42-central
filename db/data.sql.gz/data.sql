--
-- PostgreSQL database dump
--

-- Dumped from database version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: active_admin_comments; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.active_admin_comments (
    id integer NOT NULL,
    namespace character varying(255),
    body text,
    resource_id character varying(255) NOT NULL,
    resource_type character varying(255) NOT NULL,
    author_id integer,
    author_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.active_admin_comments OWNER TO micah;

--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.active_admin_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.active_admin_comments_id_seq OWNER TO micah;

--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.active_admin_comments_id_seq OWNED BY public.active_admin_comments.id;


--
-- Name: activities; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.activities (
    id integer NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL,
    subject_id integer,
    subject_type character varying(255),
    action character varying(255),
    subject_changes text,
    subject_destroyed_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.activities OWNER TO micah;

--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_id_seq OWNER TO micah;

--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying(255) DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying(255),
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    authy_id character varying,
    last_sign_in_with_authy timestamp without time zone,
    authy_enabled boolean DEFAULT false
);


ALTER TABLE public.admin_users OWNER TO micah;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_id_seq OWNER TO micah;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: api_tokens; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.api_tokens (
    id integer NOT NULL,
    team_id integer,
    token character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.api_tokens OWNER TO micah;

--
-- Name: api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.api_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_tokens_id_seq OWNER TO micah;

--
-- Name: api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.api_tokens_id_seq OWNED BY public.api_tokens.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO micah;

--
-- Name: attachinary_files; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.attachinary_files (
    id integer NOT NULL,
    attachinariable_id integer,
    attachinariable_type character varying(255),
    scope character varying(255),
    public_id character varying(255),
    version character varying(255),
    width integer,
    height integer,
    format character varying(255),
    resource_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.attachinary_files OWNER TO micah;

--
-- Name: attachinary_files_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.attachinary_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attachinary_files_id_seq OWNER TO micah;

--
-- Name: attachinary_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.attachinary_files_id_seq OWNED BY public.attachinary_files.id;


--
-- Name: changesets; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.changesets (
    id integer NOT NULL,
    story_id integer,
    project_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.changesets OWNER TO micah;

--
-- Name: changesets_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.changesets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.changesets_id_seq OWNER TO micah;

--
-- Name: changesets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.changesets_id_seq OWNED BY public.changesets.id;


--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.enrollments (
    id integer NOT NULL,
    team_id integer NOT NULL,
    user_id integer NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.enrollments OWNER TO micah;

--
-- Name: enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.enrollments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.enrollments_id_seq OWNER TO micah;

--
-- Name: enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.enrollments_id_seq OWNED BY public.enrollments.id;


--
-- Name: integrations; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.integrations (
    id integer NOT NULL,
    project_id integer,
    kind character varying(255) NOT NULL,
    data public.hstore NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.integrations OWNER TO micah;

--
-- Name: integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.integrations_id_seq OWNER TO micah;

--
-- Name: integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.integrations_id_seq OWNED BY public.integrations.id;


--
-- Name: memberships; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.memberships (
    id integer NOT NULL,
    project_id integer,
    user_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.memberships OWNER TO micah;

--
-- Name: memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.memberships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.memberships_id_seq OWNER TO micah;

--
-- Name: memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.memberships_id_seq OWNED BY public.memberships.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    note text,
    user_id integer,
    story_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    user_name character varying(255)
);


ALTER TABLE public.notes OWNER TO micah;

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notes_id_seq OWNER TO micah;

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: ownerships; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.ownerships (
    id integer NOT NULL,
    team_id integer NOT NULL,
    project_id integer NOT NULL,
    is_owner boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.ownerships OWNER TO micah;

--
-- Name: ownerships_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.ownerships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ownerships_id_seq OWNER TO micah;

--
-- Name: ownerships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.ownerships_id_seq OWNED BY public.ownerships.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying(255),
    point_scale character varying(255) DEFAULT 'fibonacci'::character varying,
    start_date date,
    iteration_start_day integer DEFAULT 1,
    iteration_length integer DEFAULT 1,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    default_velocity integer DEFAULT 10,
    slug character varying(255),
    stories_count integer DEFAULT 0,
    memberships_count integer DEFAULT 0,
    archived_at timestamp without time zone,
    disallow_join boolean DEFAULT true NOT NULL,
    tag_group_id integer,
    mail_reports boolean DEFAULT true,
    velocity_strategy integer DEFAULT 3
);


ALTER TABLE public.projects OWNER TO micah;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO micah;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO micah;

--
-- Name: stories; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.stories (
    id integer NOT NULL,
    title character varying(255),
    description text,
    estimate integer,
    story_type character varying(255) DEFAULT 'feature'::character varying,
    state character varying(255) DEFAULT 'unstarted'::character varying,
    accepted_at timestamp without time zone,
    requested_by_id integer,
    owned_by_id integer,
    project_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    "position" numeric(25,20),
    labels character varying(255),
    requested_by_name character varying(255),
    owned_by_name character varying(255),
    owned_by_initials character varying(255),
    started_at timestamp without time zone,
    cycle_time double precision DEFAULT 0.0,
    release_date date,
    delivered_at timestamp without time zone,
    branch character varying,
    new_position integer
);


ALTER TABLE public.stories OWNER TO micah;

--
-- Name: stories_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.stories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stories_id_seq OWNER TO micah;

--
-- Name: stories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.stories_id_seq OWNED BY public.stories.id;


--
-- Name: tag_groups; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.tag_groups (
    id integer NOT NULL,
    team_id integer,
    name character varying(15),
    description text,
    bg_color character varying DEFAULT '#2075F3'::character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    foreground_color character varying
);


ALTER TABLE public.tag_groups OWNER TO micah;

--
-- Name: tag_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.tag_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tag_groups_id_seq OWNER TO micah;

--
-- Name: tag_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.tag_groups_id_seq OWNED BY public.tag_groups.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    story_id integer,
    name character varying(255),
    done boolean DEFAULT false,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.tasks OWNER TO micah;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO micah;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255),
    logo character varying(255),
    archived_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    disable_registration boolean DEFAULT false NOT NULL,
    registration_domain_whitelist character varying(255),
    registration_domain_blacklist character varying(255)
);


ALTER TABLE public.teams OWNER TO micah;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO micah;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: micah
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying(128) DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying(255),
    remember_token character varying(255),
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip character varying(255),
    last_sign_in_ip character varying(255),
    confirmation_token character varying(255),
    confirmed_at timestamp without time zone,
    confirmation_sent_at timestamp without time zone,
    password_salt character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    name character varying(255),
    initials character varying(255),
    email_delivery boolean DEFAULT true,
    email_acceptance boolean DEFAULT true,
    email_rejection boolean DEFAULT true,
    reset_password_sent_at timestamp without time zone,
    locale character varying(255),
    memberships_count integer DEFAULT 0,
    username character varying(255) NOT NULL,
    time_zone character varying(255) DEFAULT 'Brasilia'::character varying NOT NULL,
    role character varying DEFAULT 'developer'::character varying NOT NULL,
    authy_id character varying,
    last_sign_in_with_authy timestamp without time zone,
    authy_enabled boolean DEFAULT false,
    finished_tour boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO micah;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: micah
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO micah;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: micah
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: active_admin_comments id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.active_admin_comments ALTER COLUMN id SET DEFAULT nextval('public.active_admin_comments_id_seq'::regclass);


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: api_tokens id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.api_tokens ALTER COLUMN id SET DEFAULT nextval('public.api_tokens_id_seq'::regclass);


--
-- Name: attachinary_files id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.attachinary_files ALTER COLUMN id SET DEFAULT nextval('public.attachinary_files_id_seq'::regclass);


--
-- Name: changesets id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.changesets ALTER COLUMN id SET DEFAULT nextval('public.changesets_id_seq'::regclass);


--
-- Name: enrollments id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.enrollments ALTER COLUMN id SET DEFAULT nextval('public.enrollments_id_seq'::regclass);


--
-- Name: integrations id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.integrations ALTER COLUMN id SET DEFAULT nextval('public.integrations_id_seq'::regclass);


--
-- Name: memberships id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.memberships ALTER COLUMN id SET DEFAULT nextval('public.memberships_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: ownerships id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.ownerships ALTER COLUMN id SET DEFAULT nextval('public.ownerships_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: stories id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.stories ALTER COLUMN id SET DEFAULT nextval('public.stories_id_seq'::regclass);


--
-- Name: tag_groups id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.tag_groups ALTER COLUMN id SET DEFAULT nextval('public.tag_groups_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: active_admin_comments; Type: TABLE DATA; Schema: public; Owner: micah
--



--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: micah
--



--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.admin_users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, authy_id, last_sign_in_with_authy, authy_enabled) VALUES (1, 'admin@example.com', '$2a$10$F0FuamyXqwUao7ov2SE24O9vAnXrmKlioOctnFOC2LRatusq654ye', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '2024-03-31 14:29:21.911534', '2024-03-31 14:29:21.911534', NULL, NULL, false);


--
-- Data for Name: api_tokens; Type: TABLE DATA; Schema: public; Owner: micah
--



--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.ar_internal_metadata (key, value, created_at, updated_at) VALUES ('environment', 'development', '2024-03-28 02:10:41.179886', '2024-03-28 02:10:41.179886');
INSERT INTO public.ar_internal_metadata (key, value, created_at, updated_at) VALUES ('schema_sha1', '27e217585c84f17c87e4ae87b8a6509b13d95d0b', '2024-03-28 02:10:41.190141', '2024-03-28 02:10:41.190141');


--
-- Data for Name: attachinary_files; Type: TABLE DATA; Schema: public; Owner: micah
--



--
-- Data for Name: changesets; Type: TABLE DATA; Schema: public; Owner: micah
--



--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.enrollments (id, team_id, user_id, is_admin, created_at, updated_at) VALUES (1, 1, 1, true, '2024-03-31 14:29:21.787997', '2024-03-31 14:29:21.787997');
INSERT INTO public.enrollments (id, team_id, user_id, is_admin, created_at, updated_at) VALUES (2, 2, 1, true, '2024-03-31 14:29:21.793847', '2024-03-31 14:29:21.793847');


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: micah
--



--
-- Data for Name: memberships; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.memberships (id, project_id, user_id, created_at, updated_at) VALUES (1, 1, 1, '2024-03-31 14:29:21.388325', '2024-03-31 14:29:21.388325');


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.notes (id, note, user_id, story_id, created_at, updated_at, user_name) VALUES (1, 'This is comment number 1', 1, 1, '2024-03-31 14:29:21.755415', '2024-03-31 14:29:21.755415', 'Foo Bar');
INSERT INTO public.notes (id, note, user_id, story_id, created_at, updated_at, user_name) VALUES (2, 'This is comment number 2', 1, 1, '2024-03-31 14:29:21.762387', '2024-03-31 14:29:21.762387', 'Foo Bar');


--
-- Data for Name: ownerships; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.ownerships (id, team_id, project_id, is_owner, created_at, updated_at) VALUES (1, 2, 1, true, '2024-03-31 14:29:21.804681', '2024-03-31 14:29:21.804681');


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.projects (id, name, point_scale, start_date, iteration_start_day, iteration_length, created_at, updated_at, default_velocity, slug, stories_count, memberships_count, archived_at, disallow_join, tag_group_id, mail_reports, velocity_strategy) VALUES (1, 'Test Project', 'fibonacci', '2024-01-31', 1, 1, '2024-03-31 14:29:21.384265', '2024-03-31 14:29:21.384265', 10, 'test-project', 69, 1, NULL, true, NULL, true, 3);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.schema_migrations (version) VALUES ('20210201140311');
INSERT INTO public.schema_migrations (version) VALUES ('20110210082458');
INSERT INTO public.schema_migrations (version) VALUES ('20110210091929');
INSERT INTO public.schema_migrations (version) VALUES ('20110316082355');
INSERT INTO public.schema_migrations (version) VALUES ('20110412083637');
INSERT INTO public.schema_migrations (version) VALUES ('20110502100528');
INSERT INTO public.schema_migrations (version) VALUES ('20110627083011');
INSERT INTO public.schema_migrations (version) VALUES ('20110706094137');
INSERT INTO public.schema_migrations (version) VALUES ('20110727105037');
INSERT INTO public.schema_migrations (version) VALUES ('20110914192131');
INSERT INTO public.schema_migrations (version) VALUES ('20110914211417');
INSERT INTO public.schema_migrations (version) VALUES ('20111005192846');
INSERT INTO public.schema_migrations (version) VALUES ('20111009095221');
INSERT INTO public.schema_migrations (version) VALUES ('20120504152649');
INSERT INTO public.schema_migrations (version) VALUES ('20150623185240');
INSERT INTO public.schema_migrations (version) VALUES ('20150625143900');
INSERT INTO public.schema_migrations (version) VALUES ('20150626134654');
INSERT INTO public.schema_migrations (version) VALUES ('20150629170320');
INSERT INTO public.schema_migrations (version) VALUES ('20150701173921');
INSERT INTO public.schema_migrations (version) VALUES ('20150827211718');
INSERT INTO public.schema_migrations (version) VALUES ('20160616195841');
INSERT INTO public.schema_migrations (version) VALUES ('20160628195845');
INSERT INTO public.schema_migrations (version) VALUES ('20160730022819');
INSERT INTO public.schema_migrations (version) VALUES ('20160818013050');
INSERT INTO public.schema_migrations (version) VALUES ('20160825181243');
INSERT INTO public.schema_migrations (version) VALUES ('20160831134320');
INSERT INTO public.schema_migrations (version) VALUES ('20160901160225');
INSERT INTO public.schema_migrations (version) VALUES ('20160901171941');
INSERT INTO public.schema_migrations (version) VALUES ('20160904163037');
INSERT INTO public.schema_migrations (version) VALUES ('20160904163124');
INSERT INTO public.schema_migrations (version) VALUES ('20160904163158');
INSERT INTO public.schema_migrations (version) VALUES ('20160905131732');
INSERT INTO public.schema_migrations (version) VALUES ('20160905141740');
INSERT INTO public.schema_migrations (version) VALUES ('20160905190120');
INSERT INTO public.schema_migrations (version) VALUES ('20160912135322');
INSERT INTO public.schema_migrations (version) VALUES ('20160912135326');
INSERT INTO public.schema_migrations (version) VALUES ('20161004200003');
INSERT INTO public.schema_migrations (version) VALUES ('20161020154028');
INSERT INTO public.schema_migrations (version) VALUES ('20161104182706');
INSERT INTO public.schema_migrations (version) VALUES ('20161208003524');
INSERT INTO public.schema_migrations (version) VALUES ('20170119174958');
INSERT INTO public.schema_migrations (version) VALUES ('20170130133949');
INSERT INTO public.schema_migrations (version) VALUES ('20170329211205');
INSERT INTO public.schema_migrations (version) VALUES ('20170329220454');
INSERT INTO public.schema_migrations (version) VALUES ('20170407114148');
INSERT INTO public.schema_migrations (version) VALUES ('20170509183608');
INSERT INTO public.schema_migrations (version) VALUES ('20170825181646');
INSERT INTO public.schema_migrations (version) VALUES ('20170914172941');
INSERT INTO public.schema_migrations (version) VALUES ('20180823124914');
INSERT INTO public.schema_migrations (version) VALUES ('20190114123043');


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (1, 'A user should be able to create bugs', NULL, NULL, 'bug', 'unstarted', NULL, 1, NULL, 1, '2024-03-31 14:29:21.455881', '2024-03-31 14:29:21.455881', 1.00000000000000000000, 'bugs', 'Foo Bar', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (2, 'A user should be able to create chores', NULL, NULL, 'chore', 'unstarted', NULL, 1, NULL, 1, '2024-03-31 14:29:21.462219', '2024-03-31 14:29:21.462219', 2.00000000000000000000, 'chores', 'Foo Bar', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (3, 'A user should be able to create releases', NULL, NULL, 'release', 'unstarted', NULL, 1, NULL, 1, '2024-03-31 14:29:21.466778', '2024-03-31 14:29:21.466778', 3.00000000000000000000, 'releases', 'Foo Bar', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (4, 'A user should be able to estimate features', NULL, 1, 'feature', 'unstarted', NULL, 1, NULL, 1, '2024-03-31 14:29:21.471155', '2024-03-31 14:29:21.471155', 4.00000000000000000000, 'estimates,features', 'Foo Bar', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (5, 'A user should be able to create features', NULL, NULL, 'feature', 'unscheduled', NULL, 1, NULL, 1, '2024-03-31 14:29:21.475491', '2024-03-31 14:29:21.475491', 5.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (6, 'A user should be able drag this story from chilly bean and drop to backlog', NULL, NULL, 'bug', 'unscheduled', NULL, 1, NULL, 1, '2024-03-31 14:29:21.479432', '2024-03-31 14:29:21.479432', 6.00000000000000000000, 'bugs', 'Foo Bar', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (7, 'A project should have some past iterations', NULL, 3, 'feature', 'accepted', '2024-03-24 14:29:21.481267', 1, NULL, 1, '2024-03-31 14:29:21.483132', '2024-03-31 14:29:21.483132', 7.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-24 14:29:21.481384', -0.000116742, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (8, 'A project should have some past iterations', NULL, 3, 'feature', 'accepted', '2024-03-17 14:29:21.485302', 1, NULL, 1, '2024-03-31 14:29:21.487405', '2024-03-31 14:29:21.487405', 8.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.4854', -9.805e-05, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (9, 'A project should have some past iterations', NULL, 3, 'feature', 'accepted', '2024-03-10 14:29:21.489206', 1, NULL, 1, '2024-03-31 14:29:21.491189', '2024-03-31 14:29:21.491189', 9.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.489284', -7.8463e-05, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (10, 'Story 0', NULL, 3, 'feature', 'accepted', '2024-02-25 14:29:21.493353', 1, NULL, 1, '2024-03-31 14:29:21.495334', '2024-03-31 14:29:21.495334', 10.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.493436', 604799.999916631, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (11, 'Story 1', NULL, 1, 'feature', 'accepted', '2024-03-24 14:29:21.49749', 1, NULL, 1, '2024-03-31 14:29:21.49937', '2024-03-31 14:29:21.49937', 11.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.497566', 604799.999923258, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (12, 'Story 2', NULL, 1, 'feature', 'accepted', '2024-02-25 14:29:21.501598', 1, NULL, 1, '2024-03-31 14:29:21.503575', '2024-03-31 14:29:21.503575', 12.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.501674', 604799.999924264, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (13, 'Story 3', NULL, 2, 'feature', 'accepted', '2024-03-03 14:29:21.505682', 1, NULL, 1, '2024-03-31 14:29:21.507656', '2024-03-31 14:29:21.507656', 13.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.505756', 604799.999925203, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (14, 'Story 4', NULL, 3, 'feature', 'accepted', '2024-03-03 14:29:21.509423', 1, NULL, 1, '2024-03-31 14:29:21.511177', '2024-03-31 14:29:21.511177', 14.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.509538', 604799.999884785, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (15, 'Story 5', NULL, 1, 'feature', 'accepted', '2024-03-17 14:29:21.513157', 1, NULL, 1, '2024-03-31 14:29:21.515074', '2024-03-31 14:29:21.515074', 15.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.51323', 604799.999927383, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (16, 'Story 6', NULL, 1, 'feature', 'accepted', '2024-03-10 14:29:21.517212', 1, NULL, 1, '2024-03-31 14:29:21.519084', '2024-03-31 14:29:21.519084', 16.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.517281', 604799.999930641, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (17, 'Story 7', NULL, 2, 'feature', 'accepted', '2024-03-10 14:29:21.521193', 1, NULL, 1, '2024-03-31 14:29:21.522925', '2024-03-31 14:29:21.522925', 17.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.521263', 604799.999930051, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (18, 'Story 8', NULL, 1, 'feature', 'accepted', '2024-02-25 14:29:21.524694', 1, NULL, 1, '2024-03-31 14:29:21.526537', '2024-03-31 14:29:21.526537', 18.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.524757', 604799.999936488, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (19, 'Story 9', NULL, 1, 'feature', 'accepted', '2024-03-03 14:29:21.528712', 1, NULL, 1, '2024-03-31 14:29:21.530582', '2024-03-31 14:29:21.530582', 19.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.52878', 604799.999932371, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (20, 'Story 10', NULL, 1, 'feature', 'accepted', '2024-03-03 14:29:21.532554', 1, NULL, 1, '2024-03-31 14:29:21.534413', '2024-03-31 14:29:21.534413', 20.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.532622', 604799.999932528, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (21, 'Story 11', NULL, 3, 'feature', 'accepted', '2024-03-17 14:29:21.536549', 1, NULL, 1, '2024-03-31 14:29:21.538386', '2024-03-31 14:29:21.538386', 21.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.536618', 604799.999931896, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (22, 'Story 12', NULL, 3, 'feature', 'accepted', '2024-03-17 14:29:21.540493', 1, NULL, 1, '2024-03-31 14:29:21.542324', '2024-03-31 14:29:21.542324', 22.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.540583', 604799.99990997, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (23, 'Story 13', NULL, 1, 'feature', 'accepted', '2024-03-17 14:29:21.544426', 1, NULL, 1, '2024-03-31 14:29:21.546328', '2024-03-31 14:29:21.546328', 23.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.544495', 604799.999930908, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (24, 'Story 14', NULL, 2, 'feature', 'accepted', '2024-03-24 14:29:21.548508', 1, NULL, 1, '2024-03-31 14:29:21.550448', '2024-03-31 14:29:21.550448', 24.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.548594', 604799.99991397, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (25, 'Story 15', NULL, 1, 'feature', 'accepted', '2024-03-03 14:29:21.552245', 1, NULL, 1, '2024-03-31 14:29:21.55394', '2024-03-31 14:29:21.55394', 25.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.552312', 604799.999932988, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (26, 'Story 16', NULL, 3, 'feature', 'accepted', '2024-03-10 14:29:21.555637', 1, NULL, 1, '2024-03-31 14:29:21.557974', '2024-03-31 14:29:21.557974', 26.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.555729', 604799.999908445, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (27, 'Story 17', NULL, 2, 'feature', 'accepted', '2024-03-24 14:29:21.560723', 1, NULL, 1, '2024-03-31 14:29:21.562914', '2024-03-31 14:29:21.562914', 27.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.560803', 604799.999920206, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (28, 'Story 18', NULL, 3, 'feature', 'accepted', '2024-03-24 14:29:21.56519', 1, NULL, 1, '2024-03-31 14:29:21.56714', '2024-03-31 14:29:21.56714', 28.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.565261', 604799.999929055, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (29, 'Story 19', NULL, 1, 'feature', 'accepted', '2024-03-03 14:29:21.569151', 1, NULL, 1, '2024-03-31 14:29:21.57106', '2024-03-31 14:29:21.57106', 29.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.569222', 604799.999928852, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (30, 'Story 20', NULL, 1, 'feature', 'accepted', '2024-03-10 14:29:21.573018', 1, NULL, 1, '2024-03-31 14:29:21.574901', '2024-03-31 14:29:21.574901', 30.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.573088', 604799.999929561, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (31, 'Story 21', NULL, 3, 'feature', 'accepted', '2024-02-25 14:29:21.576736', 1, NULL, 1, '2024-03-31 14:29:21.578506', '2024-03-31 14:29:21.578506', 31.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.576805', 604799.999930879, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (32, 'Story 22', NULL, 1, 'feature', 'accepted', '2024-03-17 14:29:21.580608', 1, NULL, 1, '2024-03-31 14:29:21.582595', '2024-03-31 14:29:21.582595', 32.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.580728', 604799.999879497, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (33, 'Story 23', NULL, 2, 'feature', 'accepted', '2024-03-17 14:29:21.584599', 1, NULL, 1, '2024-03-31 14:29:21.586516', '2024-03-31 14:29:21.586516', 33.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.584668', 604799.999931863, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (34, 'Story 24', NULL, 1, 'feature', 'accepted', '2024-02-25 14:29:21.588516', 1, NULL, 1, '2024-03-31 14:29:21.590511', '2024-03-31 14:29:21.590511', 34.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.588597', 604799.999918196, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (35, 'Story 25', NULL, 1, 'feature', 'accepted', '2024-03-17 14:29:21.592676', 1, NULL, 1, '2024-03-31 14:29:21.594601', '2024-03-31 14:29:21.594601', 35.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.592747', 604799.999928831, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (36, 'Story 26', NULL, 1, 'feature', 'accepted', '2024-03-17 14:29:21.596375', 1, NULL, 1, '2024-03-31 14:29:21.59804', '2024-03-31 14:29:21.59804', 36.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.596441', 604799.999934178, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (37, 'Story 27', NULL, 1, 'feature', 'accepted', '2024-03-10 14:29:21.599744', 1, NULL, 1, '2024-03-31 14:29:21.601408', '2024-03-31 14:29:21.601408', 37.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.599807', 604799.999937218, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (38, 'Story 28', NULL, 3, 'feature', 'accepted', '2024-03-10 14:29:21.603123', 1, NULL, 1, '2024-03-31 14:29:21.604792', '2024-03-31 14:29:21.604792', 38.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.603183', 604799.999940189, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (39, 'Story 29', NULL, 2, 'feature', 'accepted', '2024-03-24 14:29:21.606564', 1, NULL, 1, '2024-03-31 14:29:21.608238', '2024-03-31 14:29:21.608238', 39.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.60666', 604799.999904314, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (40, 'Story 30', NULL, 3, 'feature', 'accepted', '2024-02-25 14:29:21.609932', 1, NULL, 1, '2024-03-31 14:29:21.611726', '2024-03-31 14:29:21.611726', 40.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.609995', 604799.99993693, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (41, 'Story 31', NULL, 2, 'feature', 'accepted', '2024-03-03 14:29:21.613712', 1, NULL, 1, '2024-03-31 14:29:21.615606', '2024-03-31 14:29:21.615606', 41.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.613781', 604799.999930427, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (42, 'Story 32', NULL, 3, 'feature', 'accepted', '2024-02-25 14:29:21.617465', 1, NULL, 1, '2024-03-31 14:29:21.619331', '2024-03-31 14:29:21.619331', 42.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.617536', 604799.999928626, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (43, 'Story 33', NULL, 1, 'feature', 'accepted', '2024-03-03 14:29:21.621405', 1, NULL, 1, '2024-03-31 14:29:21.623175', '2024-03-31 14:29:21.623175', 43.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.621472', 604799.999932389, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (44, 'Story 34', NULL, 2, 'feature', 'accepted', '2024-03-10 14:29:21.625101', 1, NULL, 1, '2024-03-31 14:29:21.627026', '2024-03-31 14:29:21.627026', 44.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.62517', 604799.999930706, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (45, 'Story 35', NULL, 3, 'feature', 'accepted', '2024-02-25 14:29:21.629047', 1, NULL, 1, '2024-03-31 14:29:21.630926', '2024-03-31 14:29:21.630926', 45.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.629133', 604799.999914965, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (46, 'Story 36', NULL, 3, 'feature', 'accepted', '2024-03-03 14:29:21.633077', 1, NULL, 1, '2024-03-31 14:29:21.634823', '2024-03-31 14:29:21.634823', 46.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.633147', 604799.999929558, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (47, 'Story 37', NULL, 2, 'feature', 'accepted', '2024-03-24 14:29:21.636963', 1, NULL, 1, '2024-03-31 14:29:21.639488', '2024-03-31 14:29:21.639488', 47.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.637057', 604799.999905839, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (48, 'Story 38', NULL, 3, 'feature', 'accepted', '2024-03-17 14:29:21.642413', 1, NULL, 1, '2024-03-31 14:29:21.645299', '2024-03-31 14:29:21.645299', 48.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.64257', 604799.999842593, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (49, 'Story 39', NULL, 2, 'feature', 'accepted', '2024-03-10 14:29:21.647618', 1, NULL, 1, '2024-03-31 14:29:21.64969', '2024-03-31 14:29:21.64969', 49.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.647704', 604799.999913454, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (50, 'Story 40', NULL, 3, 'feature', 'accepted', '2024-03-03 14:29:21.65175', 1, NULL, 1, '2024-03-31 14:29:21.653613', '2024-03-31 14:29:21.653613', 50.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.651826', 604799.999924089, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (51, 'Story 41', NULL, 2, 'feature', 'accepted', '2024-03-17 14:29:21.655571', 1, NULL, 1, '2024-03-31 14:29:21.657339', '2024-03-31 14:29:21.657339', 51.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.655641', 604799.999930239, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (52, 'Story 42', NULL, 2, 'feature', 'accepted', '2024-03-03 14:29:21.659438', 1, NULL, 1, '2024-03-31 14:29:21.661345', '2024-03-31 14:29:21.661345', 52.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.65951', 604799.999928062, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (53, 'Story 43', NULL, 3, 'feature', 'accepted', '2024-03-03 14:29:21.663462', 1, NULL, 1, '2024-03-31 14:29:21.665123', '2024-03-31 14:29:21.665123', 53.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.663534', 604799.999928687, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (54, 'Story 44', NULL, 1, 'feature', 'accepted', '2024-02-25 14:29:21.667266', 1, NULL, 1, '2024-03-31 14:29:21.669042', '2024-03-31 14:29:21.669042', 54.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.66734', 604799.99992676, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (55, 'Story 45', NULL, 2, 'feature', 'accepted', '2024-03-24 14:29:21.671361', 1, NULL, 1, '2024-03-31 14:29:21.673155', '2024-03-31 14:29:21.673155', 55.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.671436', 604799.999925275, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (56, 'Story 46', NULL, 1, 'feature', 'accepted', '2024-03-10 14:29:21.675266', 1, NULL, 1, '2024-03-31 14:29:21.677198', '2024-03-31 14:29:21.677198', 56.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.675336', 604799.999929176, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (57, 'Story 47', NULL, 3, 'feature', 'accepted', '2024-03-10 14:29:21.679039', 1, NULL, 1, '2024-03-31 14:29:21.68082', '2024-03-31 14:29:21.68082', 57.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.679107', 604799.999931513, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (58, 'Story 48', NULL, 2, 'feature', 'accepted', '2024-03-24 14:29:21.682898', 1, NULL, 1, '2024-03-31 14:29:21.684802', '2024-03-31 14:29:21.684802', 58.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.68297', 604799.999927975, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (59, 'Story 49', NULL, 3, 'feature', 'accepted', '2024-03-03 14:29:21.686716', 1, NULL, 1, '2024-03-31 14:29:21.688635', '2024-03-31 14:29:21.688635', 59.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.686788', 604799.9999277, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (60, 'Story 50', NULL, 3, 'feature', 'accepted', '2024-03-17 14:29:21.690608', 1, NULL, 1, '2024-03-31 14:29:21.692315', '2024-03-31 14:29:21.692315', 60.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-10 14:29:21.690677', 604799.99993026, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (61, 'Story 51', NULL, 1, 'feature', 'accepted', '2024-03-10 14:29:21.694191', 1, NULL, 1, '2024-03-31 14:29:21.695862', '2024-03-31 14:29:21.695862', 61.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.694255', 604799.999935685, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (62, 'Story 52', NULL, 2, 'feature', 'accepted', '2024-02-25 14:29:21.698484', 1, NULL, 1, '2024-03-31 14:29:21.701206', '2024-03-31 14:29:21.701206', 62.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.698578', 604799.99990567, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (63, 'Story 53', NULL, 3, 'feature', 'accepted', '2024-03-03 14:29:21.704253', 1, NULL, 1, '2024-03-31 14:29:21.707167', '2024-03-31 14:29:21.707167', 63.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-25 14:29:21.704364', 604799.999889246, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (64, 'Story 54', NULL, 3, 'feature', 'accepted', '2024-03-24 14:29:21.710333', 1, NULL, 1, '2024-03-31 14:29:21.712694', '2024-03-31 14:29:21.712694', 64.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.710434', 604799.999898716, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (65, 'Story 55', NULL, 1, 'feature', 'accepted', '2024-03-24 14:29:21.714938', 1, NULL, 1, '2024-03-31 14:29:21.716722', '2024-03-31 14:29:21.716722', 65.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.715011', 604799.999926749, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (66, 'Story 56', NULL, 3, 'feature', 'accepted', '2024-03-24 14:29:21.718879', 1, NULL, 1, '2024-03-31 14:29:21.720741', '2024-03-31 14:29:21.720741', 66.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-17 14:29:21.71895', 604799.999928796, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (67, 'Story 57', NULL, 2, 'feature', 'accepted', '2024-02-25 14:29:21.723188', 1, NULL, 1, '2024-03-31 14:29:21.7251', '2024-03-31 14:29:21.7251', 67.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.723271', 604799.999917196, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (68, 'Story 58', NULL, 2, 'feature', 'accepted', '2024-02-25 14:29:21.727342', 1, NULL, 1, '2024-03-31 14:29:21.729283', '2024-03-31 14:29:21.729283', 68.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-02-18 14:29:21.727421', 604799.999921302, NULL, NULL, NULL, NULL);
INSERT INTO public.stories (id, title, description, estimate, story_type, state, accepted_at, requested_by_id, owned_by_id, project_id, created_at, updated_at, "position", labels, requested_by_name, owned_by_name, owned_by_initials, started_at, cycle_time, release_date, delivered_at, branch, new_position) VALUES (69, 'Story 59', NULL, 2, 'feature', 'accepted', '2024-03-10 14:29:21.731513', 1, NULL, 1, '2024-03-31 14:29:21.733536', '2024-03-31 14:29:21.733536', 69.00000000000000000000, 'features', 'Foo Bar', NULL, NULL, '2024-03-03 14:29:21.731589', 604799.999924044, NULL, NULL, NULL, NULL);


--
-- Data for Name: tag_groups; Type: TABLE DATA; Schema: public; Owner: micah
--



--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: micah
--



--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.teams (id, name, slug, logo, archived_at, created_at, updated_at, disable_registration, registration_domain_whitelist, registration_domain_blacklist) VALUES (1, 'Archive Team', 'archive-team', NULL, '2024-03-31 14:29:21.763627', '2024-03-31 14:29:21.776305', '2024-03-31 14:29:21.776305', false, NULL, NULL);
INSERT INTO public.teams (id, name, slug, logo, archived_at, created_at, updated_at, disable_registration, registration_domain_whitelist, registration_domain_blacklist) VALUES (2, 'Default', 'default', NULL, NULL, '2024-03-31 14:29:21.792087', '2024-03-31 14:29:21.792087', false, NULL, NULL);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: micah
--

INSERT INTO public.users (id, email, encrypted_password, reset_password_token, remember_token, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, confirmation_token, confirmed_at, confirmation_sent_at, password_salt, created_at, updated_at, name, initials, email_delivery, email_acceptance, email_rejection, reset_password_sent_at, locale, memberships_count, username, time_zone, role, authy_id, last_sign_in_with_authy, authy_enabled, finished_tour) VALUES (1, 'foo@bar.com', '$2a$10$/RlARA5b6VG1wuVaO/CHO.sHLj3Xe1T60QppfGaKGaBg/y/Z/rB2S', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 'yFcKxTfsKyoZjMxFVKHy', '2024-03-31 14:29:21.291031', '2024-03-31 14:29:21.288621', NULL, '2024-03-31 14:29:21.287215', '2024-03-31 14:29:21.291237', 'Foo Bar', 'FB', true, true, true, NULL, NULL, 1, 'foobar', 'Brasilia', 'developer', NULL, NULL, false, false);


--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.active_admin_comments_id_seq', 1, false);


--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.activities_id_seq', 1, false);


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- Name: api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.api_tokens_id_seq', 1, false);


--
-- Name: attachinary_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.attachinary_files_id_seq', 1, false);


--
-- Name: changesets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.changesets_id_seq', 1, false);


--
-- Name: enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.enrollments_id_seq', 2, true);


--
-- Name: integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.integrations_id_seq', 1, false);


--
-- Name: memberships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.memberships_id_seq', 1, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.notes_id_seq', 2, true);


--
-- Name: ownerships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.ownerships_id_seq', 1, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, true);


--
-- Name: stories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.stories_id_seq', 69, true);


--
-- Name: tag_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.tag_groups_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.teams_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: micah
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: active_admin_comments active_admin_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.active_admin_comments
    ADD CONSTRAINT active_admin_comments_pkey PRIMARY KEY (id);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: api_tokens api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: attachinary_files attachinary_files_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.attachinary_files
    ADD CONSTRAINT attachinary_files_pkey PRIMARY KEY (id);


--
-- Name: changesets changesets_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.changesets
    ADD CONSTRAINT changesets_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: memberships memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: ownerships ownerships_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.ownerships
    ADD CONSTRAINT ownerships_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_pkey PRIMARY KEY (id);


--
-- Name: tag_groups tag_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.tag_groups
    ADD CONSTRAINT tag_groups_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: by_scoped_parent; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX by_scoped_parent ON public.attachinary_files USING btree (attachinariable_type, attachinariable_id, scope);


--
-- Name: index_active_admin_comments_on_author_type_and_author_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_active_admin_comments_on_author_type_and_author_id ON public.active_admin_comments USING btree (author_type, author_id);


--
-- Name: index_active_admin_comments_on_namespace; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_active_admin_comments_on_namespace ON public.active_admin_comments USING btree (namespace);


--
-- Name: index_active_admin_comments_on_resource_type_and_resource_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_active_admin_comments_on_resource_type_and_resource_id ON public.active_admin_comments USING btree (resource_type, resource_id);


--
-- Name: index_activities_on_project_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_activities_on_project_id ON public.activities USING btree (project_id);


--
-- Name: index_activities_on_project_id_and_user_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_activities_on_project_id_and_user_id ON public.activities USING btree (project_id, user_id);


--
-- Name: index_activities_on_user_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_activities_on_user_id ON public.activities USING btree (user_id);


--
-- Name: index_admin_users_on_authy_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_admin_users_on_authy_id ON public.admin_users USING btree (authy_id);


--
-- Name: index_admin_users_on_email; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_admin_users_on_email ON public.admin_users USING btree (email);


--
-- Name: index_admin_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_admin_users_on_reset_password_token ON public.admin_users USING btree (reset_password_token);


--
-- Name: index_api_tokens_on_team_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_api_tokens_on_team_id ON public.api_tokens USING btree (team_id);


--
-- Name: index_enrollments_on_team_id_and_user_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_enrollments_on_team_id_and_user_id ON public.enrollments USING btree (team_id, user_id);


--
-- Name: index_integrations_on_data; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_integrations_on_data ON public.integrations USING gin (data);


--
-- Name: index_memberships_on_project_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_memberships_on_project_id ON public.memberships USING btree (project_id);


--
-- Name: index_memberships_on_project_id_and_user_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_memberships_on_project_id_and_user_id ON public.memberships USING btree (project_id, user_id);


--
-- Name: index_memberships_on_user_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_memberships_on_user_id ON public.memberships USING btree (user_id);


--
-- Name: index_ownerships_on_team_id_and_project_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_ownerships_on_team_id_and_project_id ON public.ownerships USING btree (team_id, project_id);


--
-- Name: index_projects_on_slug; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_projects_on_slug ON public.projects USING btree (slug);


--
-- Name: index_tag_groups_on_team_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_tag_groups_on_team_id ON public.tag_groups USING btree (team_id);


--
-- Name: index_tasks_on_story_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_tasks_on_story_id ON public.tasks USING btree (story_id);


--
-- Name: index_teams_on_name; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_teams_on_name ON public.teams USING btree (name);


--
-- Name: index_teams_on_slug; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_teams_on_slug ON public.teams USING btree (slug);


--
-- Name: index_users_on_authy_id; Type: INDEX; Schema: public; Owner: micah
--

CREATE INDEX index_users_on_authy_id ON public.users USING btree (authy_id);


--
-- Name: index_users_on_confirmation_token; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_users_on_confirmation_token ON public.users USING btree (confirmation_token);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: micah
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: enrollments enrollments_team_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_team_id_fk FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: enrollments enrollments_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_user_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: integrations integrations_project_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_project_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: memberships memberships_project_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_project_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: memberships memberships_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_user_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notes notes_story_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_story_id_fk FOREIGN KEY (story_id) REFERENCES public.stories(id) ON DELETE CASCADE;


--
-- Name: ownerships ownerships_project_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.ownerships
    ADD CONSTRAINT ownerships_project_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: ownerships ownerships_team_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.ownerships
    ADD CONSTRAINT ownerships_team_id_fk FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: stories stories_project_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_project_id_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_story_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: micah
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_story_id_fk FOREIGN KEY (story_id) REFERENCES public.stories(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

